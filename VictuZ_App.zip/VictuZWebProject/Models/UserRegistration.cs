﻿namespace VictuZWebProject.Models
{
    public class UserRegistration
    {
        public int Id { get; set; }
        public string UserId { get; set; }  // Identity user ID
        public int ActivityId { get; set; }
    }
}
