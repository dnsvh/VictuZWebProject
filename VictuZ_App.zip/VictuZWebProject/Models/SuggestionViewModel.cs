﻿namespace VictuZWebProject.Models
{
    public class SuggestionViewModel
    {
        public Suggestion Suggestion { get; set; }
        public bool HasUserLiked { get; set; }
    }
}
